package com.example.hhs.hotelapp;

/**
 * Created by subash on 26/2/17.
 */

public class Quantity
{
    public static String qty;

    public static String getQty() {
        return qty;
    }

    public static void setQty(String qty) {
        Quantity.qty = qty;
    }
}
