package com.example.hhs.hotelapp;

import java.util.AbstractCollection;
import java.util.ArrayList;

/**
 * Created by subash on 25/2/17.
 */

public class Dist {
    public static String radius="5000";
    public static ArrayList<DataObject>foods;
    public static int amount=0;
}
