package com.example.hhs.hotelapp;

/**
 * Created by subash on 25/2/17.
 */

public class CredsUpdate

{
    public CredsUpdate(){}
    public String uname,uaddr,mobnum,upass,upass2;

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getUaddr() {
        return uaddr;
    }

    public void setUaddr(String uaddr) {
        this.uaddr = uaddr;
    }

    public String getMobnum() {
        return mobnum;
    }

    public void setMobnum(String mobnum) {
        this.mobnum = mobnum;
    }

    public String getUpass() {
        return upass;
    }

    public void setUpass(String upass) {
        this.upass = upass;
    }

    public String getUpass2() {
        return upass2;
    }

    public void setUpass2(String upass2) {
        this.upass2 = upass2;
    }
}
